source("db_con.R")
library(shiny)
library(shinyTime)
library(shinyalert)
library(shinyjs)
library(DT)


function(input, output) {

  
  # Grupy docelowe
  
  output$tabelaGrupyDoceloweOutput <- DT::renderDataTable({
    sql <- "SELECT * FROM grupy_docelowe;"
    dbGetQuery(con,sql)
  })
  
  
  # Rodzaje wycieczek
  
  output$tabelaRodzajeOutput <- DT::renderDataTable({
    sql <- "SELECT id_rodzaju_wycieczki AS id, r.opis_wycieczki AS rodzaj, r.cena, g.opis_grupy AS grupa_docelowa
    FROM rodzaje_wycieczek r JOIN grupy_docelowe g ON(r.grupa_docelowa = g.id_grupy);"
    dbGetQuery(con,sql)
  })
  
  
  wektor_rodzajow <- dbGetQuery(con, "SELECT id_rodzaju_wycieczki FROM rodzaje_wycieczek;")
  output$rodzajeSelector_us <- renderUI({
    selectInput(inputId = "rodzaj_do_us", label = "Wybierz rodzaj wycieczki do usunięcia", choices = wektor_rodzajow, selected = 1)
  })
  
  ## Usun rodzaj wycieczki

  observeEvent(input$rodzaj_usun,{
    sql <- paste0("DELETE FROM rodzaje_wycieczek WHERE id_rodzaju_wycieczki = ", input$rodzaj_do_us, ";")
    dbSendQuery(con, sql)
    output$tabelaRodzajeOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT id_rodzaju_wycieczki AS id, r.opis_wycieczki AS rodzaj, r.cena, g.opis_grupy AS grupa_docelowa
    FROM rodzaje_wycieczek r JOIN grupy_docelowe g ON(r.grupa_docelowa = g.id_grupy);")
    })
    wektor_rodzajow <- dbGetQuery(con, "SELECT id_rodzaju_wycieczki FROM rodzaje_wycieczek;")
    output$rodzajeSelector_us <- renderUI({
      selectInput(inputId = "rodzaj_do_us", label = "Wybierz rodzaj wycieczki do usunięcia", choices = wektor_rodzajow, selected = 1)
    })
  })
  
  ## Dodaj rodzaj wycieczki
  
  wektor_grup <- dbGetQuery(con, "SELECT id_grupy FROM grupy_docelowe;")
  
  output$grupySelector_dod <- renderUI({
    selectInput(inputId = "grupa_docelowa", label = "Wybierz grupę docelową", choices = wektor_grup, selected = 1)
  })
  
  observeEvent(input$rodzaj_dodaj, {
    sql <- paste0("INSERT INTO rodzaje_wycieczek(opis_wycieczki, cena, grupa_docelowa) 
                  VALUES ('", input$opis_wycieczki, " ',",  input$cena, ",", input$grupa_docelowa,");")
    dbSendQuery(con, sql)
    output$tabelaRodzajeOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT id_rodzaju_wycieczki AS id, r.opis_wycieczki AS rodzaj, r.cena, g.opis_grupy AS grupa_docelowa
    FROM rodzaje_wycieczek r JOIN grupy_docelowe g ON(r.grupa_docelowa = g.id_grupy);")
    })
    
  })
  
  
# Klienci
  
  output$tabelaKlienciOutput <- DT::renderDataTable({
    sql <- "SELECT id_uczestnika as ID, imie_uczestnika AS Imię, 
    nazwisko_uczestnika AS Nazwisko, telefon, email  FROM uczestnicy;"
    dbGetQuery(con,sql)
  })
  
  wektor_klientow <- dbGetQuery(con, "SELECT id_uczestnika FROM uczestnicy;")
  output$klienciSelector <- renderUI({
    selectInput(inputId = "klient_do_us", label = "Wybierz klienta do usunięcia", choices = wektor_klientow, selected = 1)
  })
  
  ## Dodaj klienta
  
  observeEvent(input$klient_dodaj, {
    sql <- paste0("INSERT INTO uczestnicy(imie_uczestnika, nazwisko_uczestnika, telefon, email) 
                  VALUES ('", input$imie_uczestnika, "', '", input$nazwisko_uczestnika, "', ",
                  input$telefon, ", '", input$email, "');")
    dbSendQuery(con, sql)
    output$tabelaKlienciOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT id_uczestnika as ID, imie_uczestnika AS Imię, 
    nazwisko_uczestnika AS Nazwisko, telefon, email  FROM uczestnicy;")
    })
    wektor_klientow <- dbGetQuery(con, "SELECT id_uczestnika FROM uczestnicy;")
    output$klienciSelector <- renderUI({
      selectInput(inputId = "klient_do_us", label = "Wybierz klienta do usunięcia", choices = wektor_klientow, selected = 1)
    })
    
    
  })
  
  ## usun klienta
  
  observeEvent(input$klient_usun,{
    sql <- paste0("DELETE FROM uczestnicy WHERE id_uczestnika = '", input$klient_do_us, "';")
    dbSendQuery(con, sql)
    output$tabelaKlienciOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT id_uczestnika as ID, imie_uczestnika AS Imię,
    nazwisko_uczestnika AS Nazwisko, telefon, email  FROM uczestnicy;")
    })
    wektor_klientow <- dbGetQuery(con, "SELECT id_uczestnika FROM uczestnicy;")
    output$klienciSelector <- renderUI({
      selectInput(inputId = "klient_do_us", label = "Wybierz klienta do usunięcia", choices = wektor_klientow, selected = 1)
    })
  })

  
# Uczestnicy
  
  output$tabelaUczestnicyOutput <- DT::renderDataTable({
    sql <- "SELECT w.id_wycieczki, u.id_uczestnika, u.imie_uczestnika AS imię,
    u.nazwisko_uczestnika AS nazwisko, pozostalo_do_zaplacenia
    FROM wycieczki w JOIN uczestnicy_wycieczki USING(id_wycieczki)
    JOIN uczestnicy u USING(id_uczestnika);"
    dbGetQuery(con,sql)
  })
  
  wektor_uczestnikow <- dbGetQuery(con, "SELECT id_uczestnika FROM uczestnicy;")
  output$uczestnicySelector <- renderUI({
    selectInput(inputId = "uczestnik_do_dod", label = "Wybierz uczestnika", choices = wektor_uczestnikow, selected = 1)
  })
  
  wektor_wycieczek <- dbGetQuery(con, "SELECT id_wycieczki FROM wycieczki;")
  output$wycieczkiSelector <- renderUI({
    selectInput(inputId = "wycieczka_do_dod", label = "Wybierz wycieczkę", choices = wektor_wycieczek, selected = 1)
  })
  
  ## Dodaj uczestnika do wycieczki
  
  observeEvent(input$uczestnik_dodaj, {
      sql <- paste0("INSERT INTO uczestnicy_wycieczki(id_uczestnika, id_wycieczki, pozostalo_do_zaplacenia) 
                  VALUES (", input$uczestnik_do_dod, ", ", input$wycieczka_do_dod,",100);")
      dbSendQuery(con, sql)
      output$tabelaUczestnicyOutput <- DT::renderDataTable({
        dbGetQuery(con, "SELECT w.id_wycieczki, u.id_uczestnika, u.imie_uczestnika AS imię,
        u.nazwisko_uczestnika AS nazwisko, pozostalo_do_zaplacenia
        FROM wycieczki w JOIN uczestnicy_wycieczki USING(id_wycieczki)
        JOIN uczestnicy u USING(id_uczestnika);")
      })
      
  })
  
  ## Wpłata
  
  wektor_uczestnikow_wplata <- dbGetQuery(con, "SELECT id_uczestnika FROM uczestnicy_wycieczki;")
  output$uczestnicyWplatySelector <- renderUI({
    selectInput(inputId = "uczestnik_do_wplaty", label = "Wybierz uczestnika", choices = wektor_uczestnikow_wplata, selected = 1)
  })
  
  wektor_wycieczki_wplata <- dbGetQuery(con, "SELECT id_wycieczki FROM uczestnicy_wycieczki;")
  output$wycieczkiWplatySelector <- renderUI({
    selectInput(inputId = "wycieczka_do_wplaty", label = "Wybierz wycieczkę", choices = wektor_wycieczki_wplata, selected = 1)
  })
  
  observeEvent(input$wplata, {
    sql <- paste0("UPDATE uczestnicy_wycieczki SET pozostalo_do_zaplacenia = ", input$pozostalo_do_zap,
                  " WHERE id_uczestnika = ", input$uczestnik_do_wplaty, " AND id_wycieczki = ", input$wycieczka_do_wplaty, ";")
    dbSendQuery(con, sql)
    output$tabelaUczestnicyOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT w.id_wycieczki, u.id_uczestnika, u.imie_uczestnika AS imię,
        u.nazwisko_uczestnika AS nazwisko, pozostalo_do_zaplacenia
        FROM wycieczki w JOIN uczestnicy_wycieczki USING(id_wycieczki)
        JOIN uczestnicy u USING(id_uczestnika);")
    })
    
  })

# Piloci
  
  output$tabelaPilociOutput <- DT::renderDataTable({
    sql <- "SELECT p.id_pilota as ID, p.imie_pilota AS Imię, nazwisko_pilota AS Nazwisko,
    r.opis_wycieczki AS uprawnienia
    FROM piloci p LEFT JOIN uprawnienia_pilota USING(id_pilota)
    LEFT JOIN rodzaje_wycieczek r USING (id_rodzaju_wycieczki);"
    dbGetQuery(con,sql)
  })
  
  wektor_pilotow <- dbGetQuery(con, "SELECT id_pilota FROM piloci;")
  output$pilociSelector <- renderUI({
    selectInput(inputId = "pilot_do_us", label = "Wybierz pilota do usunięcia", choices = wektor_pilotow, selected = 1)
  })

## dodaj pilota
  
  observeEvent(input$pilot_dodaj, {
      sql <- paste0("INSERT INTO piloci(imie_pilota, nazwisko_pilota) VALUES ('", input$imie_pilota, "', '", input$nazwisko_pilota, "');")
      dbSendQuery(con, sql)
      output$tabelaPilociOutput <- DT::renderDataTable({
        dbGetQuery(con, "SELECT p.id_pilota as ID, p.imie_pilota AS Imię, nazwisko_pilota AS Nazwisko,
                  r.opis_wycieczki AS uprawnienia
                  FROM piloci p LEFT JOIN uprawnienia_pilota USING(id_pilota)
                  LEFT JOIN rodzaje_wycieczek r USING (id_rodzaju_wycieczki);")
      })
      wektor_pilotow <- dbGetQuery(con, "SELECT id_pilota FROM piloci;")
      output$pilociSelector <- renderUI({
        selectInput(inputId = "pilot_do_us", label = "Wybierz pilota do usunięcia", choices = wektor_pilotow, selected = 1)
      })

    
  })
  
## usun pilota

  observeEvent(input$pilot_usun,{
    sql <- paste0("DELETE FROM piloci WHERE id_pilota = '", input$pilot_do_us, "';")
    dbSendQuery(con, sql)
    output$tabelaPilociOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT p.id_pilota as ID, p.imie_pilota AS Imię, nazwisko_pilota AS Nazwisko,
                  r.opis_wycieczki AS uprawnienia
                  FROM piloci p LEFT JOIN uprawnienia_pilota USING(id_pilota)
                  LEFT JOIN rodzaje_wycieczek r USING (id_rodzaju_wycieczki);")
    })
    wektor_pilotow <- dbGetQuery(con, "SELECT id_pilota FROM piloci;")
    output$pilociSelector <- renderUI({
      selectInput(inputId = "pilot_do_us", label = "Wybierz pilota do usunięcia", choices = wektor_pilotow, selected = 1)
    })
  })
  
## Dodaj uprawnienia pilota
  wektor_pilotow_add <- dbGetQuery(con, "SELECT id_pilota FROM piloci;")
  output$pilociSelector_add <- renderUI({
    selectInput(inputId = "pilot_do_dod", label = "Wybierz pilota", choices = wektor_pilotow_add, selected = 1)
  })
  
  wektor_uprawnienia <- dbGetQuery(con, "SELECT id_rodzaju_wycieczki FROM rodzaje_wycieczek;")
  output$uprawnieniaSelector_add <- renderUI({
    selectInput(inputId = "uprawnienie_do_dod", label = "Wybierz uprawnienie", choices = wektor_uprawnienia, selected = 1)
  })
  
  observeEvent(input$uprawnienie_dodaj, {
    sql <- paste0("INSERT INTO uprawnienia_pilota(id_pilota, id_rodzaju_wycieczki) VALUES (", input$pilot_do_dod, ",", input$uprawnienie_do_dod, ");")
    dbSendQuery(con, sql)
    output$tabelaPilociOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT p.id_pilota as ID, p.imie_pilota AS Imię, nazwisko_pilota AS Nazwisko,
                  r.opis_wycieczki AS uprawnienia
                  FROM piloci p LEFT JOIN uprawnienia_pilota USING(id_pilota)
                  LEFT JOIN rodzaje_wycieczek r USING (id_rodzaju_wycieczki);")
    })
    wektor_pilotow_add <- dbGetQuery(con, "SELECT id_pilota FROM piloci;")
    output$pilociSelector_add <- renderUI({
      selectInput(inputId = "pilot_do_dod", label = "Wybierz pilota", choices = wektor_pilotow_add, selected = 1)
    })
    
    wektor_uprawnienia <- dbGetQuery(con, "SELECT id_rodzaju_wycieczki FROM rodzaje_wycieczek;")
    output$uprawnieniaSelector_add <- renderUI({
      selectInput(inputId = "uprawnienie_do_dod", label = "Wybierz uprawnienie", choices = wektor_uprawnienia, selected = 1)
    })
  })


# Kierowcy

output$tabelaKierowcyOutput <- DT::renderDataTable({
  sql <- "SELECT id_kierowcy AS ID, imie_kierowcy AS imię, nazwisko_kierowcy AS nazwisko FROM kierowcy;"
  dbGetQuery(con,sql)
})

wektor_kierowcow <- dbGetQuery(con, "SELECT id_kierowcy FROM kierowcy;")
output$kierowcySelector <- renderUI({
  selectInput(inputId = "kierowca_do_us", label = "Wybierz kierowcę do usunięcia", choices = wektor_kierowcow, selected = 1)
})

## dodaj kierowcę

observeEvent(input$kierowca_dodaj, {
  sql <- paste0("INSERT INTO kierowcy(imie_kierowcy, nazwisko_kierowcy) VALUES ('", input$imie_kierowcy, "', '", 
                input$nazwisko_kierowcy, "');")
  dbSendQuery(con, sql)
  output$tabelaKierowcyOutput <- DT::renderDataTable({
    dbGetQuery(con, "SELECT id_kierowcy AS ID, imie_kierowcy AS imię, nazwisko_kierowcy AS nazwisko FROM kierowcy;")
  })
  wektor_kierowcow <- dbGetQuery(con, "SELECT id_kierowcy FROM kierowcy;")
  output$kierowcySelector <- renderUI({
    selectInput(inputId = "kierowca_do_us", label = "Wybierz kierowcę do usunięcia", choices = wektor_kierowcow, selected = 1)
  })
  
})
  
## usun kierowcę
  
  observeEvent(input$kierowca_usun,{
    sql <- paste0("DELETE FROM kierowcy WHERE id_kierowcy = ", input$kierowca_do_us, ";")
    dbSendQuery(con, sql)
    output$tabelaKieorwcyOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT id_kierowcy AS ID, imie_kierowcy AS imię, nazwisko_kierowcy AS nazwisko FROM kierowcy;")
    })
    wektor_kierowcow <- dbGetQuery(con, "SELECT id_kierowcy FROM kierowcy;")
    output$kierowcySelector <- renderUI({
      selectInput(inputId = "kierowcy_do_us", label = "Wybierz kierowcę do usunięcia", choices = wektor_kierowcow, selected = 1)
    })
})
  
  
# Autokary
  
  output$tabelaAutokaryOutput <- DT::renderDataTable({
    sql <- "SELECT id_autokaru AS ID, liczba_miejsc AS Miejsca FROM autokary;"
    dbGetQuery(con,sql)
  })
  
  wektor_autokarow <- dbGetQuery(con, "SELECT id_autokaru FROM autokary;")
  output$autokarySelector <- renderUI({
    selectInput(inputId = "autokar_do_us", label = "Wybierz autokar do usunięcia", choices = wektor_autokarow, selected = 1)
  })
  
  ## dodaj autokar
  
  observeEvent(input$autokar_dodaj, {
    sql <- paste0("INSERT INTO autokary(liczba_miejsc) VALUES (", input$liczba_miejsc, ");")
    dbSendQuery(con, sql)
    output$tabelaAutokaryOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT id_autokaru AS ID, liczba_miejsc AS Miejsca FROM autokary;")
    })
    wektor_autokarow <- dbGetQuery(con, "SELECT id_autokaru FROM autokary;")
    output$autokarySelector <- renderUI({
      selectInput(inputId = "autokar_do_us", label = "Wybierz autokar do usunięcia", choices = wektor_autokarow, selected = 1)
    })
    
    
  })
  
  ## usun autokar
  
  observeEvent(input$autokar_usun,{
    sql <- paste0("DELETE FROM autokary WHERE id_autokaru = '", input$autokar_do_us, "';")
    dbSendQuery(con, sql)
    output$tabelaAutokaryOutput <- DT::renderDataTable({
      dbGetQuery(con, "SELECT id_autokaru AS ID, liczba_miejsc AS Miejsca FROM autokary;")
    })
    wektor_autokarow <- dbGetQuery(con, "SELECT id_autokaru FROM autokary;")
    output$autokarySelector <- renderUI({
      selectInput(inputId = "autokar_do_us", label = "Wybierz autokar do usunięcia", choices = wektor_autokarow, selected = 1)
    })
  })
  
  
  # Wycieczki  
  
  output$tabelaWycieczkiOutput <- DT::renderDataTable({
    sql <- "SELECT w.id_wycieczki as ID, p.nazwisko_pilota AS pilot,
    k.nazwisko_kierowcy AS kierowca, id_autokaru AS autokar,
    w.termin_od, w.termin_do, rw.opis_wycieczki AS rodzaj,
    w.max_liczba_uczestnikow
    
    FROM wycieczki w JOIN autokary a USING (id_autokaru)
    JOIN kierowcy k USING(id_kierowcy)
    JOIN piloci p USING(id_pilota)
    JOIN rodzaje_wycieczek rw ON(w.rodzaj_wycieczki = rw.id_rodzaju_wycieczki);
    "
    dbGetQuery(con,sql)
  })
  
  observeEvent(input$wyszukaj, {
    output$tabelaWycieczkiOutput <- DT::renderDataTable({
      sql <- paste0("SELECT w.id_wycieczki as ID, p.nazwisko_pilota AS pilot,
      k.nazwisko_kierowcy AS kierowca, id_autokaru AS autokar,
      w.termin_od, w.termin_do, rw.opis_wycieczki AS rodzaj,
      w.max_liczba_uczestnikow
      FROM wycieczki w JOIN autokary a USING (id_autokaru)
      JOIN kierowcy k USING(id_kierowcy)
      JOIN piloci p USING(id_pilota)
      JOIN rodzaje_wycieczek rw ON(w.rodzaj_wycieczki = rw.id_rodzaju_wycieczki)
      WHERE w.termin_od >= ", "'", input$data_szukaj[1], "'", " AND w.termin_do <= ", "'",
                    input$data_szukaj[2], "'", ";")
      dbGetQuery(con,sql)
    })
  })
  
  ## Dodaj wycieczkę
  
  wektor_pilotow_add_W <- dbGetQuery(con, "SELECT id_pilota FROM piloci;")
  output$pilociSelector_add_W <- renderUI({
    selectInput(inputId = "pilot_do_dod_W", label = "Wybierz pilota", choices = wektor_pilotow_add_W, selected = 1)
  })
  
  wektor_kierowcow_add_W <- dbGetQuery(con, "SELECT id_kierowcy FROM kierowcy;")
  output$kierowcySelector_add_W <- renderUI({
    selectInput(inputId = "kierowca_do_dod_W", label = "Wybierz kierowcę", choices = wektor_kierowcow_add_W, selected = 1)
  })

  wektor_autokarow_add_W <- dbGetQuery(con, "SELECT id_autokaru FROM autokary;")
  output$autokarySelector_add_W <- renderUI({
    selectInput(inputId = "autokar_do_dod_W", label = "Wybierz autokar", choices = wektor_autokarow_add_W, selected = 1)
  })
  
  wektor_rodzaje_add_W <- dbGetQuery(con, "SELECT id_rodzaju_wycieczki FROM rodzaje_wycieczek;")
  output$rodzajeSelector_add_W <- renderUI({
    selectInput(inputId = "rodzaj_do_dod_W", label = "Wybierz rodzaj wycieczki", choices = wektor_rodzaje_add_W, selected = 1)
  })
  
  observeEvent(input$wycieczka_dodaj, {
     sql <- paste0("INSERT INTO wycieczki(id_pilota, id_autokaru, id_kierowcy, rodzaj_wycieczki,
                   termin_od, termin_do, max_liczba_uczestnikow) VALUES (",
                   input$pilot_do_dod_W, ",", input$autokar_do_dod_W, ",", input$kierowca_do_dod_W,
                   ",",  input$rodzaj_do_dod_W,",'",input$terminy[1], "','", input$terminy[2],"',",
                   input$max_liczba_uczestnikow_W,");")
     dbSendQuery(con, sql)
     output$tabelaWycieczkiOutput <- DT::renderDataTable({
       dbGetQuery(con, "SELECT w.id_wycieczki as ID, p.nazwisko_pilota AS pilot,
       k.nazwisko_kierowcy AS kierowca, id_autokaru AS autokar,
       w.termin_od, w.termin_do, rw.opis_wycieczki AS rodzaj,
       w.max_liczba_uczestnikow
  
       FROM wycieczki w JOIN autokary a USING (id_autokaru)
       JOIN kierowcy k USING(id_kierowcy)
       JOIN piloci p USING(id_pilota)
       JOIN rodzaje_wycieczek rw ON(w.rodzaj_wycieczki = rw.id_rodzaju_wycieczki);")
     })

   })
  
  ## Wycieczki z wolnymi miejscami
  
  output$tabelaWolneOutput <- DT::renderDataTable({
    sql <- "SELECT * FROM liczba_wolnych_miejsc_na_wycieczke;"
    dbGetQuery(con,sql)
  })
  
  
}