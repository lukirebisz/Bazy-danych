library("RPostgres")

##### polaczenie z baza danych
open.my.connection <- function() {
  con <- dbConnect(RPostgres::Postgres(),dbname = 'postgres', 
                   host = 'localhost',
                   port = 5432, 
                   user = 'lukirebisz',
                   password = 'BazyDanych')
  return (con)
}

close.my.connection <- function(con) {
  dbDisconnect(con)
}

