
fluidPage(
  titlePanel("Witamy w biurze podróży!"),
  tabsetPanel(
    tabPanel("Wyświetl dane",
        tabsetPanel(
          tabPanel("Wycieczki",
                   sidebarPanel(
                     dateRangeInput("data_szukaj", label = h3("Wycieczki terminach:"), language = 'pl'),
                     actionButton(inputId = "wyszukaj", label = "Wyszukaj")
                   ),
                     mainPanel(
                     tags$h3("Lista wycieczek:"),
                     DT::dataTableOutput(outputId = "tabelaWycieczkiOutput")
                   ),
                   sidebarPanel(
                     tags$h3("Wolne miejsca:"),
                     DT::dataTableOutput(outputId = "tabelaWolneOutput")
                     
                   ),
                   sidebarPanel(
                     tags$h3("Dodaj wycieczkę"),
                     uiOutput("pilociSelector_add_W"),
                     uiOutput("kierowcySelector_add_W"),
                     uiOutput("autokarySelector_add_W"),
                     dateRangeInput("terminy", label = h3("Termin wycieczki:"), language = 'pl'),
                     uiOutput("rodzajeSelector_add_W"),
                     numericInput(inputId = "max_liczba_uczestnikow_W", label = "Podaj max liczbę uczestników", value = 1, min = 1),
                     actionButton(inputId = "wycieczka_dodaj", label = "Dodaj")

                   ),
                   sidebarPanel(
                     tags$h3("Rodzaje wycieczek:"),
                     DT::dataTableOutput(outputId = "tabelaRodzajeOutput"),
                     width=10
                   ),
                   sidebarPanel(
                     tags$h3("Grupy_docelowe:"),
                     DT::dataTableOutput(outputId = "tabelaGrupyDoceloweOutput"),
                     width=5
                   ),
                   sidebarPanel(
                     tags$h3("Usuwanie rodzaju:"),
                     uiOutput("rodzajeSelector_us"),
                     actionButton(inputId = "rodzaj_usun", label = "Usuń"),
                     
                     tags$h3("Dodawanie rodzaju:"),
                     textInput(inputId = "opis_wycieczki", label = "Wpisz opis wycieczki"),
                     numericInput(inputId = "cena", label = "Podaj cenę", value = 1000, min = 1),
                     uiOutput("grupySelector_dod"),
                     actionButton(inputId = "rodzaj_dodaj", label = "Dodaj")
                   )
                   ),
          tabPanel("Klienci",
                   sidebarPanel(
                     tags$h3("Dodawanie klienta:"),
                     textInput(inputId = "imie_uczestnika", label = "Wpisz imię klienta"),
                     textInput(inputId = "nazwisko_uczestnika", label = "Wpisz nazwisko klienta"),
                     numericInput(inputId = "telefon", label = "Podaj numer telefonu", value = 123456789, min = 1),
                     textInput(inputId = "email", label = "Wpisz email"),
                     actionButton(inputId = "klient_dodaj", label = "Dodaj klienta"),
                     
                     tags$h3("Usuwanie klienta:"),
                     uiOutput("klienciSelector"),
                     actionButton(inputId = "klient_usun", label = "Usuń")
                   ),
                   mainPanel(
                     tags$h3("Lista klientów:"),
                     DT::dataTableOutput(outputId = "tabelaKlienciOutput")
                   ),
                   sidebarPanel(
                     tags$h3("Zapisz uczestnika na wycieczkę:"),
                     uiOutput("uczestnicySelector"),
                     uiOutput("wycieczkiSelector"),
                     actionButton(inputId = "uczestnik_dodaj", label = "Zapisz")
                   ),
                   sidebarPanel(
                     tags$h3("Wpłata klienta:"),
                     uiOutput("uczestnicyWplatySelector"),
                     uiOutput("wycieczkiWplatySelector"),
                     numericInput(inputId = "pozostalo_do_zap", label = "Pozostało do zapłacenia", value = 0, min = 0),
                     actionButton(inputId = "wplata", label = "Zapisz")
                   ),
                   sidebarPanel(
                     tags$h3("Lista uczestników wycieczek:"),
                     DT::dataTableOutput(outputId = "tabelaUczestnicyOutput"),
                     width=10
                   )
                   ),
          tabPanel("Personel",
                   tabsetPanel(
                     tabPanel("Piloci",
                              sidebarPanel(
                                tags$h3("Dodawanie pilota:"),
                                textInput(inputId = "imie_pilota", label = "Wpisz imię pilota"),
                                textInput(inputId = "nazwisko_pilota", label = "Wpisz nazwisko pilota"),
                                actionButton(inputId = "pilot_dodaj", label = "Dodaj pilota"),
                                
                                tags$h3("Usuwanie pilota:"),
                                uiOutput("pilociSelector"),
                                actionButton(inputId = "pilot_usun", label = "Usuń"),
                                
                                tags$h3("Dodawanie uprawnień:"),
                                uiOutput("pilociSelector_add"),
                                uiOutput("uprawnieniaSelector_add"),
                                actionButton(inputId = "uprawnienie_dodaj", label = "Dodaj uprawnienie")

                              ),
                              
                              mainPanel(
                                tags$h3("Lista pilotów:"),
                                DT::dataTableOutput(outputId = "tabelaPilociOutput")
                              )
                              ),
                     tabPanel("Kierowcy",
                              sidebarPanel(
                                tags$h3("Dodawanie kierowcy:"),
                                textInput(inputId = "imie_kierowcy", label = "Wpisz imię kierowcy"),
                                textInput(inputId = "nazwisko_kierowcy", label = "Wpisz nazwisko kierowcy"),
                                actionButton(inputId = "kierowca_dodaj", label = "Dodaj kierowcę"),
                                tags$h3("Usuwanie kierowcy:"),
                                uiOutput("kierowcySelector"),
                                actionButton(inputId = "kierowca_usun", label = "Usuń")
                              ),
                              mainPanel(
                                tags$h3("Lista kierowców:"),
                                DT::dataTableOutput(outputId = "tabelaKierowcyOutput")
                              )),
                     tabPanel("Autokary",
                              sidebarPanel(
                                tags$h3("Dodawanie autokaru:"),
                                numericInput(inputId = "liczba_miejsc", label = "Podaj liczbę miejsc", value = 0, min = 1),
                                actionButton(inputId = "autokar_dodaj", label = "Dodaj autokar"),
                                tags$h3("Usuwanie autokaru:"),
                                uiOutput("autokarySelector"),
                                actionButton(inputId = "autokar_usun", label = "Usuń")
                              ),
                              mainPanel(
                                tags$h3("Lista autokarów:"),
                                DT::dataTableOutput(outputId = "tabelaAutokaryOutput")
                              ))
                   ))
          
          
          
          
        )
    )
    
  )
)


