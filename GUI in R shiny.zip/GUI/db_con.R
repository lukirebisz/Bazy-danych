library(RPostgres)

con <- dbConnect(RPostgres::Postgres(),dbname = 'postgres', 
                 host = 'localhost',
                 port = 5432, 
                 user = 'lukirebisz',
                 password = 'BazyDanych')
